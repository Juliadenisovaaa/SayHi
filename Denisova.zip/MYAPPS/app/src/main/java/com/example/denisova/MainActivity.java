package com.example.denisova;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    private TextView mainTextView;
    private Button startButton;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startButton = findViewById(R.id.button3);
        mainTextView = findViewById(R.id.main_textview);
        imageView = findViewById(R.id.myImageView);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainTextView.setText(R.string.text1);
                imageView.setVisibility(View.VISIBLE);
            }
        });
        imageView.setVisibility(View.GONE);

    }
}